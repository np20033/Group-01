#!/bin/bash

declare -A servers=(
  ["172.23.182.238"]="Messaging"
   ["172.23.94.225"]="FrontEnd"
  ["172.23.199.180"]="Backend"
  ["172.23.130.128"]="Database"
  ["172.23.119.210"]="Database"
)

for ip in "${!servers[@]}"; do
    echo "Checking status of ${servers[$ip]} (${ip})..."
    if ping -c1 -W5 "$ip" >/dev/null 2>&1; then
        echo -e "\e[1;34m${servers[$ip]}:\t\e[0m\e[1;33m(${ip})\t\e[0m is \e[1;32mONLINE(✔)\e[0m"
    else
        echo -e "\e[1;34m${servers[$ip]}:\t\e[0m\e[1;33m(${ip})\t\e[0m is \e[1;31mOFFLINE(✘)\e[0m"
    fi
done 