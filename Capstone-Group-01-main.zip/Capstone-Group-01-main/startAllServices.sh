#!/bin/bash

ssh drana7@172.23.182.238 'cd ~/Capstone-Group-01/Messaging && composer startRabbitmq &'
ssh drl3_it490server@172.23.199.180 'cd ~/Capstone-Group-01/Backend && composer startBackend &'
ssh khushi@172.23.94.225 'cd ~/Capstone-Group-01/FrontEnd && composer startfrontend &'
ssh mtg24@172.23.130.128 'cd ~/Capstone-Group-01/Database && composer start-mysql &'
ssh neha@172.23.119.210 'cd ~/Capstone-Group-01/Database && composer start-mysql &'

echo "All Services Started!"