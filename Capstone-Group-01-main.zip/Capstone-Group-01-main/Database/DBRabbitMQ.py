import mysql.connector 
import json
import pika
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'password'
MYSQL_DATABASE = 'moviestacks'
RABBITMQ_HOST = '172.23.182.238'


def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        print("Connected to MySQL database")
        return connection
    except mysql.connector.Error as e:
        print("Error connecting to MySQL database:", e)
        return None
    
def connect_to_rabbitmq():
    try:
        credentials = pika.PlainCredentials("admin","admin")
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, port=5672, credentials=credentials))
        channel = connection.channel()
        print("Connected to RabbitMQ on host:", RABBITMQ_HOST)
        return channel
    except Exception as e:
        print("Error connecting to RabbitMQ:", e)
        return None



def send_message_to_rabbitmq(channel, message):
    try:
        channel.queue_declare(queue='regDB2RT', durable=True)
        channel.basic_publish(exchange='', routing_key='regDB2RT', body=json.dumps(message))
        print(f" [x] Sent message to queue {'regDB2RT'}: {message}")
    except Exception as e:
        print("Error sending message to RabbitMQ:", e)

def test_send_message():
    channel = connect_to_rabbitmq()
    message_test = {
        "sender": "database",
        "receiver": "backend",
        "purpose": "registration",
        "action": "registration_step3",
        "email": "mike@njit.edu",
        "username": "mtg24",
        "firstname": "Michael",
        "lastname": "Gallo",
        "password": "test123",
        "confirm": "test123",
        "security_question": "What is your name",
        "security_answer": "Mike"
    }
    if channel:
        # Your message content
        send_message_to_rabbitmq(channel, message_test)
        channel.close()
    else:
        print("Failed to connect to RabbitMQ.")



#test_send_message()


def confirm_user_register(success=True):
    
    try:
        channel = connect_to_rabbitmq()
        if channel: 
            confirm_new_user = {
                "sender": "database",
                "receiver": "backend",
                "purpose": "registration",
                "action": "register_user_step5",
                "status": success


            }

            message= json.dumps(confirm_new_user)

            send_message_to_rabbitmq(channel,message)
            print("Confirmation message sent for user registration.")

        else:
            print("Failed to connect to RabbitMQ.")

    except Exception as e:
        print("Error sending confirmation message to RabbitMQ:", e)



def confirm_user_exists( exists=True):
    try:
        channel = connect_to_rabbitmq()
        
        first_name = last_name = username = email = password = security_question = security_answer = None
        
        connection= connect_to_database()
        if connection:
            cursor = connection.cursor()
            query = "SELECT first_name, last_name, username, email, password, security_question, security_answer FROM users WHERE username = %s OR email = %s"
            cursor.execute(query)
            result = cursor.fetchone()
            if result:
                first_name, last_name, username, email, password, security_question, security_answer = result
            else:
                first_name = last_name = username = email = password = security_question = security_answer = None

            cursor.close()
            connection.close()
        
        if channel:
            confirm_user = {
                "sender": "database",
                "receiver": "backend",
                "purpose": "registration",
                "action": "register_user_step3",
                "results": exists,
                "first_name": first_name,
                "last_name": last_name,
                "username": username,
                "email": email,
                "password": password,
                "security_question": security_question,
                "security_answer": security_answer

                

            }

            message = json.dumps(confirm_user)

            send_message_to_rabbitmq(channel, message)
            print("Confirmation message sent for confirming user exists.")

        else:
            print("Failed to connect to RabbitMQ.")
    except Exception as e:
        print("Error sending confirmation message to RabbitMQ:", e)


#for users table
def insert_user(ch, method, properties, body):
    try:
        connection = connect_to_database()
        if connection:
            cursor = connection.cursor()
            

            message = json.loads(body.decode())
            if message.get("purpose") == "registration" and message.get("action") == "register_user_step4":
                # Extract user data from the message
                user_data = {
                    "first_name": message.get("first_name"),
                    "last_name": message.get("last_name"),
                    "username": message.get("username"),
                    "email": message.get("email"),
                    "password": message.get("password"),
                    "security_question": message.get("security_question"),
                    "security_answer": message.get("security_answer")
                    # 'confirm_password': message.get('confirm_password')  # You may choose to include this if needed
                }
            if all(user_data.values()):
                # Execute the SQL query to insert the data into the 'users' table
                query = "INSERT INTO users (first_name, last_name, username, email, password, security_question, security_answer) VALUES (%s, %s, %s, %s, %s, %s,%s)"
                cursor.execute(query, ( user_data['first_name'], user_data['last_name'], user_data['username'],user_data['email'],user_data['password'], user_data['security_question'], user_data['security_answer']))
                connection.commit()
                print("New User inserted into 'users' table successfully")

                confirm_user_register(success=True)
            else:
                    print("Missing or invalid user data in the message")
                    confirm_user_register(success=False)

        else:
            print("Message is not for user registration or action is not 'create_user'")


            cursor.close()
            connection.close()
    except Exception as e:
        print("Error processing message from RabbitMQ:", e)



def check_user_exists(ch, method, properties, body):
    try:
        connection = connect_to_database()
        if connection:
            cursor = connection.cursor()
            
            message = json.loads(body.decode())
            if message.get("purpose") == "registration" and message.get("action") == "register_user_step2":
                # Extract username and email from the message
                username = message.get("username")
                email = message.get("email")

                # Initialize variables to track username and email existence
                username_exists = email_exists = False
                
                # Check username existence
                query_username = "SELECT COUNT(*) FROM users WHERE username = %s"
                cursor.execute(query_username, (username,))
                count_username = cursor.fetchone()[0]
                if count_username > 0:
                    print(f"User with username '{username}' exists.")
                    username_exists = True
                
                # Check email existence
                query_email = "SELECT COUNT(*) FROM users WHERE email = %s"
                cursor.execute(query_email, (email,))
                count_email = cursor.fetchone()[0]
                if count_email > 0:
                    print(f"User with email '{email}' exists.")
                    email_exists = True

                # Perform actions based on username and email existence
                if username_exists or email_exists:
                    confirm_user_exists(exists=True)
                else:
                    confirm_user_exists(exists=False)
            else:
                print("Message is not for user existence check or action is not 'check_user'")
            
            cursor.close()
            connection.close()
    except Exception as e:
        print("Error processing message from RabbitMQ:", e)



def recieve_message_from_rabbitmq():
    try:
        channel = connect_to_rabbitmq()
        if channel:
            channel.queue_declare(queue='regRT2DB', durable=True)
            print(" [*] Waiting for messages from queue", 'regRT2DB')

            def callback(ch, method, properties, body):
                try:
                    message = json.loads(body.decode())
                    print("Received message:", message)

                    if message.get("purpose") == "registration":
                        if message.get("action") == "register_user_step4":
                            insert_user(ch, method, properties, body)
                        elif message.get("action") == "register_user_step2":
                            check_user_exists(ch, method, properties, body)
                    else:
                        print("Unhandled action:", message.get("action"))

                except json.JSONDecodeError as e:
                    print("Error decoding JSON:", e)
                    # Handle the error gracefully

            channel.basic_consume(queue='regRT2DB', on_message_callback=callback, auto_ack=True)
            channel.start_consuming()

            recieve_message_from_rabbitmq()

    except Exception as e:
        print("Error consuming messages from RabbitMQ:", e)




recieve_message_from_rabbitmq()




















''' def authenticate_user(username_or_email, password):
    try:
        mysql_connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        cursor = mysql_connection.cursor()

        # Check if the username_or_email exists in the users table
        query = "SELECT user_id, username, email, password FROM users WHERE username = %s OR email = %s"
        cursor.execute(query, (username_or_email, username_or_email))
        user_data = cursor.fetchone()

        if user_data:
            user_id, username, email, stored_password = user_data
            # Check if the entered password matches the stored password
            if password == stored_password:
                print("Authentication successful for user:", username)
                return True
            else:
                print("Incorrect password for user:", username)
                return False
        else:
            print("User not found")
            return False
    except mysql.connector.Error as err:
        print("Error:", err)
        return False
    finally:
        if 'mysql_connection' in locals():
            mysql_connection.close()

#test function
            '''