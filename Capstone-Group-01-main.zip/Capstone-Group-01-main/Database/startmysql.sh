#!/bin/bash

if sudo systemctl is-active --quiet mysql.service; then
	echo "MYSQL is already running. "
else
	sudo service mysql start
	echo "MYSQL started successfully."
fi
