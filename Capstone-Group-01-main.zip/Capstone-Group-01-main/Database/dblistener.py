import mysql.connector 

import pika
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'password'
MYSQL_DATABASE = 'moviestacks'
RABBITMQ_HOST = '172.23.182.238'

def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        print("Connected to MySQL database")
        return connection
    except mysql.connector.Error as e:
        print("Error connecting to MySQL database:", e)
        return None
    
    
def checkUserExists(username):
    try:
        mysql_connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        cursor = mysql_connection.cursor()

        query = "SELECT COUNT(*) FROM users WHERE username = %s"
        cursor.execute(query, (username,))
        result = cursor.fetchone()[0]

        cursor.close()
        mysql_connection.close()

        return result > 0
    except mysql.connector.Error as err:
        print("Error:", err)
        return False


#172.23.182.238
    

# Test the functio
    
username = input("Enter the username to check: ")
if checkUserExists(username):
    print("True")
else:
    print("False") 

    



def authenticate_user(username_or_email, password):
    try:
        mysql_connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        cursor = mysql_connection.cursor()

        # Check if the username_or_email exists in the users table
        query = "SELECT user_id, username, email, password FROM users WHERE username = %s OR email = %s"
        cursor.execute(query, (username_or_email, username_or_email))
        user_data = cursor.fetchone()

        if user_data:
            user_id, username, email, stored_password = user_data
            # Check if the entered password matches the stored password
            if password == stored_password:
                print("Authentication successful for user:", username)
                return True
            else:
                print("Incorrect password for user:", username)
                return False
        else:
            print("User not found")
            return False
    except mysql.connector.Error as err:
        print("Error:", err)
        return False
    finally:
        if 'mysql_connection' in locals():
            mysql_connection.close()

#test function
            
'''

username_or_email = input("Enter username or email: ")
password = input("Enter password: ")
authenticate_user(username_or_email, password)


'''





def create_user(username, email, first_name, last_name, hashed_password):

    try:
        mysql_connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        cursor = mysql_connection.cursor()

        # Insert the user into the users table
        query = "INSERT INTO users (first_name, last_name, username, email, password) VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(query, (first_name, last_name, username, email, hashed_password))
        mysql_connection.commit()
        print("User saved successfully.")
        return True
    except mysql.connector.Error as err:
        print("Error:", err)
        return False
    finally:
        if 'mysql_connection' in locals():
            mysql_connection.close()


#R
            


def connect_to_rabbitmq():
    try:
        credentials = pika.PlainCredentials("admin","admin")
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, port=5672, credentials=credentials))
        channel = connection.channel()
        print("Connected to RabbitMQ on host:", RABBITMQ_HOST)
        return channel
    except Exception as e:
        print("Error connecting to RabbitMQ:", e)
        return None

channel = connect_to_rabbitmq()
if channel:
    print("RabbitMQ connection successful.")
else:
    print("Failed to connect to RabbitMQ.")



        

