import mysql.connector 
import json
import pika
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'password'
MYSQL_DATABASE = 'moviestacks'
RABBITMQ_HOST = '172.23.182.238'


def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        print("Connected to MySQL database")
        return connection
    except mysql.connector.Error as e:
        print("Error connecting to MySQL database:", e)
        return None
    
def connect_to_rabbitmq():
    try:
        credentials = pika.PlainCredentials("admin","admin")
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, port=5672, virtual_host='/', credentials=credentials))
        channel = connection.channel()
        print("Connected to RabbitMQ on host:", RABBITMQ_HOST)
        return channel
    except Exception as e:
        print("Error connecting to RabbitMQ:", e)
        return None



def send_message_to_rabbitmq(channel, message):
    try:
        channel.queue_declare(queue='regDB2BE', durable=True)
        channel.basic_publish(exchange='', routing_key='regDB2BE', body=json.dumps(message))
        print(f" [x] Sent message to queue {'regDB2BE'}: {message}")
    except Exception as e:
        print("Error sending message to RabbitMQ:", e)




def test_send_message():
    channel = connect_to_rabbitmq()
    message_test = {
        "sender": "database",
        "receiver": "backend",
        "purpose": "registration",
        "action": "registration_step3",
        "email": "mike@njit.edu",
        "username": "mtg24",
        "firstname": "Michael",
        "lastname": "Gallo",
        "password": "test123",
        "confirm": "test123",
        "security_question": "What is your name",
        "security_answer": "Mike"
    }
    if channel:
        # Your message content
        send_message_to_rabbitmq(channel, message_test)
        channel.close()
    else:
        print("Failed to connect to RabbitMQ.")



#test_send_message()


def check_user_exists(username,first_name,last_name, email,password, security_question, security_answer, channel):
    try:
        # Connect to the database
        connection = connect_to_database()
        if connection:
            cursor = connection.cursor(buffered=True)

            # Execute the query to check if the user exists
            print("prepping user query")
            query= "SELECT * FROM users WHERE username = %s"
            cursor.execute(query, (username,))
            user = cursor.fetchone()
            print(user)


            query_email = "SELECT * FROM users where email = %s"
            cursor.execute(query_email,(email,))
            user_email= cursor.fetchone()
            print(user_email)



            cursor.close()
            connection.close()


            # If user exists, send a confirmation message
            if user or user_email :
                print("user already exists ")
                confirmation_message = {

                   "sender": "database",
                        "receiver": "backend",
                        "purpose": "registration",
                         "action": "register_user_step3",
                        "results": True,
                        "username": username,
                        "firstname": first_name,
                        "lastname": last_name,
                        "email": email,
                        "password": password,
                        "security_question": security_question,
                        "security_answer": security_answer
                }
                
               
                send_message_to_rabbitmq(channel, confirmation_message)
                print("Sent confirmation message to RabbitMQ: User exists")

                
            else:
                    print("Sent confirmation message to RabbitMQ: User does not exist")
                # Send a failed confirmation message
                    failed_confirmation_message = {
                        "sender": "database",
                        "receiver": "backend",
                        "purpose": "registration",
                         "action": "register_user_step3",
                        "results": False,
                        "username": username,
                        "firstname": first_name,
                        "lastname": last_name,
                        "email": email,
                        "password": password,
                        "security_question": security_question,
                        "security_answer": security_answer
                    }
                    send_message_to_rabbitmq(channel, failed_confirmation_message)
                    
        else:
            print("Error connecting to the database.")
    except Exception as e:
        print("Error checking if user exists:", e)




#for users table
def insert_user(first_name, last_name, username, email, password, security_question, security_answer, channel):
    try:
        connection = connect_to_database()
        if connection:
            cursor = connection.cursor(buffered=True)

            
            # Execute the query to insert the user
            print("going to insert user")
            query = "INSERT INTO users (first_name, last_name, username, email, password, security_question, security_answer) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            cursor.execute(query, (first_name, last_name, username, email, password, security_question, security_answer))
            connection.commit()
            cursor.close()
            connection.close()



            print("user has been inserted")
            confirmation_message = {
                "sender": "database",
                "receiver": "backend",
                "purpose": "registration",
                "action": "register_user_step5",
                "results": True,
                "username": username
        
            }

            # Send confirmation message
            print("sending message")
            send_message_to_rabbitmq(connect_to_rabbitmq(), confirmation_message)
            return True
        else:
            print("Error connecting to the database.")
            failed_confirmation_message = {
                "sender": "database",
                "receiver": "backend",
                "purpose": "registration",
                "action": "register_user_step5",
                "results": False,
                "username": username
            }
            send_message_to_rabbitmq(connect_to_rabbitmq(), failed_confirmation_message)
            return False
        
    except Exception as e:
        print("Error inserting user:", e)
        failed_confirmation_message = {
            "sender": "database",
            "receiver": "backend",
            "purpose": "registration",
            "action": "register_user_step5",
            "results": False,
            "username": username
        
        }
        send_message_to_rabbitmq(connect_to_rabbitmq(), failed_confirmation_message)
        return False
    



def recieve_message_from_rabbitmq():
    try:
        channel = connect_to_rabbitmq()
        if channel:
            channel.queue_declare(queue='regBE2DB', durable=True)
            print(" [*] Waiting for messages from queue", 'regBE2DB')

            def callback(ch, method, properties, body):
                try:
                    message = json.loads(body.decode())
                    print("Received message:", message)

                    if message.get("purpose") == "registration":
                        if message.get("action") =="register_user_step2":
                            print("this is on step 2")
                            first_name = message.get("firstname")
                            last_name = message.get("lastname")
                            username = message.get("username")
                            email = message.get("email")
                            password = message.get("password")
                            security_question = message.get("security_question")
                            security_answer = message.get("security_answer")
                            if username: 
                                print("run check if user exists the user exists")
                                check_user_exists(username, first_name, last_name,email, password, security_question,security_answer, ch)
                            else:
                                print("no username")
                        
                        elif message.get("action") == "register_user_step4":
                            
                            first_name = message.get("firstname")
                            last_name = message.get("lastname")
                            username = message.get("username")
                            email = message.get("email")
                            password = message.get("password")
                            security_question = message.get("security_question")
                            security_answer = message.get("security_answer")
                            
                            insert_user(first_name, last_name, username, email, password, security_question, security_answer, ch)

                            

                            

                    else:
                        print("Unhandled action:", message.get("action"))

                except json.JSONDecodeError as e:
                    print("Error decoding JSON:", e)

            
            channel.basic_consume(queue='regBE2DB', on_message_callback=callback, auto_ack=True)
            channel.start_consuming()  
        

    except Exception as e:
        print("Error consuming messages from RabbitMQ:", e)



recieve_message_from_rabbitmq()
















''' def authenticate_user(username_or_email, password):
    try:
        mysql_connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        cursor = mysql_connection.cursor()

        # Check if the username_or_email exists in the users table
        query = "SELECT user_id, username, email, password FROM users WHERE username = %s OR email = %s"
        cursor.execute(query, (username_or_email, username_or_email))
        user_data = cursor.fetchone()

        if user_data:
            user_id, username, email, stored_password = user_data
            # Check if the entered password matches the stored password
            if password == stored_password:
                print("Authentication successful for user:", username)
                return True
            else:
                print("Incorrect password for user:", username)
                return False
        else:
            print("User not found")
            return False
    except mysql.connector.Error as err:
        print("Error:", err)
        return False
    finally:
        if 'mysql_connection' in locals():
            mysql_connection.close()

#test function
            '''