import mysql.connector 
import json
import pika
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'password'
MYSQL_DATABASE = 'moviestacks'
RABBITMQ_HOST = '172.23.182.238'


def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        print("Connected to MySQL database")
        return connection
    except mysql.connector.Error as e:
        print("Error connecting to MySQL database:", e)
        return None
    

def connect_to_rabbitmq():
    try:
        credentials = pika.PlainCredentials("admin","admin")
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, port=5672, credentials=credentials))
        channel = connection.channel()
        print("Connected to RabbitMQ on host:", RABBITMQ_HOST)
        return channel
    except Exception as e:
        print("Error connecting to RabbitMQ:", e)
        return None
    




def send_message_to_rabbitmq(channel, message):
    try:
        channel.queue_declare(queue='logDB2BE', durable=True)
        channel.basic_publish(exchange='', routing_key='logDB2BE', body=json.dumps(message))
        print(f" [x] Sent message to queue {'logDB2BE'}: {message}")
    except Exception as e:
        print("Error sending message to RabbitMQ:", e)




def check_user_exists(username_email,password, channel):
    try:
        # Connect to the database
        connection = connect_to_database()
        if connection:
            cursor = connection.cursor(buffered=True)

            # Execute the query to check if the user exists
            print("prepping user query")
            query = "SELECT * FROM users WHERE (username = %s OR email = %s)"
            cursor.execute(query, (username_email, username_email))
            user = cursor.fetchone()


            passwordquery= "SELECT password from users where username =%s or email = %s"
            cursor.execute(passwordquery, (username_email,username_email))
            user_password=cursor.fetchone()
            user_password = user_password[0] if user_password else None  # Extract password from tuple
        
        

            

            cursor.close()
            connection.close()


            # If user exists, send a confirmation message
            if user :
                print("user exists and everything matches, they can login")
                confirmation_message = {

                   "sender": "database",
                        "receiver": "backend",
                        "purpose": "login",
                         "action": "login_step3",
                        "results": True,
                        "username_email": username_email,
                        "password": password,
                        "database_password": user_password,
                       
                }
                
               
                send_message_to_rabbitmq(channel, confirmation_message)
                print("Sent confirmation message to RabbitMQ: User exists")

                
            else:
                    print("User info doesnt match up")
                # Send a failed confirmation message
                    failed_confirmation_message = {
                         "sender": "database",
                        "receiver": "backend",
                        "purpose": "login",
                         "action": "login_step3",
                        "results": False,
                        "username_email": username_email,
                        "password": None,
                        "database_password": None,
                       
        
                    
                    }
                    send_message_to_rabbitmq(channel, failed_confirmation_message)
                    
        else:
            print("Error connecting to the database.")
            failed_confirmation_message = {
                         "sender": "database",
                        "receiver": "backend",
                        "purpose": "login",
                         "action": "login_step3",
                        "results": False,
                        "username_email": username_email,
                        "password": None,
                    
                    }
            send_message_to_rabbitmq(channel, failed_confirmation_message)
    except Exception as e:
        print("Error checking if user exists:", e)



def check_credentials(username, password, channel):
    try:
        # Connect to the database
        connection = connect_to_database()
        if connection:
            cursor = connection.cursor(buffered=True)

            # Execute the query to check if the username and password match
            query = "SELECT * FROM users WHERE (username = %s OR email = %s) AND password = %s"
            cursor.execute(query, (username, username, password))
            user = cursor.fetchone()
            cursor.close()
            connection.close()

            # Prepare confirmation message
            confirmation_message = {
                "sender": "database",
                "receiver": "backend",
                "purpose": "login",
                "action": "login_step5",
                "results": user is not None,  # True if username and password match, False otherwise
                
            }

            # Publish confirmation message to RabbitMQ
            send_message_to_rabbitmq(channel, confirmation_message)

            if user:
                print("Sent confirmation message to RabbitMQ: Username and password match")
            else:
                print("Sent confirmation message to RabbitMQ: Username and password do not match")

            return user is not None  # Return True if username and password match, False otherwise
        else:
            print("Error connecting to the database.")
            return False
    except Exception as e:
        print("Error checking credentials:", e)
        return False



def recieve_message_from_rabbitmq():
    try:
        channel = connect_to_rabbitmq()
        if channel:
            channel.queue_declare(queue='logBE2DB', durable=True)
            print(" [*] Waiting for messages from queue", 'logBE2DB')

            def callback(ch, method, properties, body):
                try:
                    message = json.loads(body.decode())
                    print("Received message:", message)

                    if message.get("purpose") == "login":
                        if message.get("action") =="login_step2":
                            username_email= message.get("username_email")
                            password= message.get("password")
                            if username_email: 
                                   check_user_exists(username_email, password, ch)
                            else:
                                print("no username")
                        
    


                    else:
                        print("Unhandled action:", message.get("action"))

                except json.JSONDecodeError as e:
                    print("Error decoding JSON:", e)

            
            channel.basic_consume(queue='logBE2DB', on_message_callback=callback, auto_ack=True)
            channel.start_consuming()  
        

    except Exception as e:
        print("Error consuming messages from RabbitMQ:", e)


recieve_message_from_rabbitmq()