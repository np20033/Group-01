from django.shortcuts import render
import json
import pika
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from .forms import UserLoginValidationForm
from django.contrib.auth.hashers import make_password, check_password
import threading

def checkValidForm(data):
    """
    Checks if the inputted data is a valid first name, last name, username, email, and password

    Args:
        data: Dictionary containing user login data

    Returns:
        Boolean
    """
    form = UserLoginValidationForm(data)

    if form.is_valid():
        return True
    else: 
        return False

def userExists(data):
    """
    Checks if the user exists through the entered username or email (sends a request to database)

    Args:
        data: Dictionary containing user login data

    Returns:
        None
    """
    form = UserLoginValidationForm(data)
    if form.is_valid():
        username_email = form.cleaned_data['username_email']
        password = form.cleaned_data['password']

        user_login = {
            "sender": "backend",
            "receiver": "database",
            "purpose": "login",
            "action": "login_step2",
            "username_email": username_email,
            "password": password
        }

        sendToDatabase(user_login)
    else:
        loginFail(None, message="Invalid Username/Email/Password")

def passwordCheck(data):
    """
    Checks if passwords match and then logins in the user if they do (sends results to frontend)

    Args:
        data: Dictionary containing user login data

    Returns:
        None
    """
    password = data.get("password")
    hashed_password = data.get("database_password")

    if check_password(password, hashed_password):
        loginSuccess(data)
    else:
        loginFail(None, message="Incorrect Password")

def loginSuccess(data):
    """
    Sends a success message once the user account is logged in (sends to frontend)

    Args:
        data: Dictionary containing user login data

    Returns:
        None
    """
    successMessage = {
        "sender": "backend",
        "receiver": "frontend",
        "purpose": "login",
        "results": True,
        "status": "Success"
    }

    sendToFrontEnd(successMessage)


def loginFail(data, message):
    """
    Sends a failure message if user was not able to log in (sends to frontend)

    Args:
        data: JSON object containing data related to the failed login attempt
        message: Error message to send

    Returns:
        Json Response
    """
    try:
        failMessage = {
            "sender": "backend",
            "receiver": "frontend",
            "purpose": "login",
            "results": message,
            "status": "Failed"
        }

        sendToFrontEnd(failMessage)
    except Exception as e:
        print(f"Error processing loginFail request: {str(e)}")

def sendToFrontEnd(message):
    """
    Publishes a message to the logBE2FE queue

    Args:
        message: Dictionary containing user login data

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    # Creating the connection to RabbitMQ Server
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    # Declaring the queue
    queue = "logBE2FE"

    channel.basic_publish(exchange='', routing_key=queue, body=json.dumps(message), properties=pika.BasicProperties(
        delivery_mode=2,  # Make the message persistent
    ))
    print(f"Response sent to logBE2FE queue:\n{message} \n ")
    connection.close()

def sendToDatabase(message):
    """
    Publishes a message to the logBE2DB queue

    Args:
        message: Dictionary containing user registration data

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    # Creating the connection to RabbitMQ Server
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    # Declaring the queue
    queue = "logBE2DB"

    channel.basic_publish(exchange='', routing_key=queue, body=json.dumps(message), properties=pika.BasicProperties(
        delivery_mode=2,  # Make the message persistent
    ))
    print(f"Response sent to logBE2DB queue:\n{message} \n ")
    connection.close()

def login_frontend_consumer():
    """
    Main consumer for logFE2BE, uses callback function to respond appropriately

    Args:
        None

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'
    
    # Creating the connection to RabbitMQ Server
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    # Declaring the QUEUE NAME 
    queue = "logFE2BE"
    channel.queue_declare(queue=queue, durable=True)

    def callback(ch, method, properties, body):
        try:
            message_data = json.loads(body)
            print(f"Received Message from logFE2BE:\n{message_data}\n")

            if message_data.get("action") == "login_step1":
                if checkValidForm(message_data):
                    userExists(message_data)
                else:
                    loginFail(None, message="Invalid Username/Email/Password")
            elif "error" in message_data:
                loginFail(None, message=message_data.get("error"))
        except Exception as e:
            loginFail(None, message=str(e))

    # Waiting for Messages to Consume
    channel.basic_consume(queue=queue, on_message_callback=callback, auto_ack=True)

    print('Waiting for messages on logFE2BE. To exit press CTRL+C')
    channel.start_consuming()

def login_database_consumer():
    """
    Main consumer for logDB2BE, uses callback function to respond appropriately

    Args:
        None

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'
    
    # Creating the connection to RabbitMQ Server
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    # Declaring the queue
    queue = "logDB2BE"
    channel.queue_declare(queue=queue, durable=True)

    def callback(ch, method, properties, body):
        try:
            message_data = json.loads(body)
            print(f"Received Message from logDB2BE:\n{message_data}\n")

            if message_data.get("action") == "login_step3":
                userExistsCheck = message_data.get("results")
                if userExistsCheck:
                    passwordCheck(message_data)
                else:
                    loginFail(None, message="Incorrect username/email")
            elif "error" in message_data:
                loginFail(None, message=message_data.get("error"))
        except Exception as e:
            loginFail(None, message=str(e))

    # Waiting for Messages to Consume
    channel.basic_consume(queue=queue, on_message_callback=callback, auto_ack=True)

    print('Waiting for messages on logDB2BE. To exit press CTRL+C')
    channel.start_consuming()


def start_rabbitmq_consumers():
    """
    Function to start the login consumer queues through threads

    Args:
        None

    Returns:
        None
    """
    try:
        frontend_thread = threading.Thread(target=login_frontend_consumer, daemon=True)
        database_thread = threading.Thread(target=login_database_consumer, daemon=True)

        frontend_thread.start()
        database_thread.start()
    except Exception as e:
        print(f"Error starting login threads: {str(e)}")

