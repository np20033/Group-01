#!/bin/bash

if pgrep -f "python3.10 manage.py runserver" > /dev/null; then
    echo "Backend Django server is online."
else
    echo "Backend Django server is offline."
fi