from django.apps import AppConfig


class It490AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'it490app'

    def ready(self):
        # Import the function to start the RabbitMQ consumer
        from .views import start_rabbitmq_consumers

        # Start the RabbitMQ consumer when the app is ready
        start_rabbitmq_consumers()