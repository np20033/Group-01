from django.http import JsonResponse
import requests
from decouple import config
import json
import pika
import threading

def get_popular_movies(request, page=1):
    """
    Returns the API data of the most popular movies per requested page (sends to frontend)

    Args:
        request: Not used
        page: The requested page number

    Returns:
        None
    """
    api_key = config('TMDB_API_KEY')
    base_url = 'https://api.themoviedb.org/3/movie/popular'
    params = {'api_key': api_key, 'page': page}

    response = requests.get(base_url, params=params)

    if response.status_code == 200:
        data = response.json()
        movie_data = {
            "sender": "backend",
            "receiver": "frontend",
            "purpose": "api",
            "action": "get_popular_movies",
            "results": data
        }

        sendToFrontEnd(movie_data)

        # return JsonResponse(data)
    else:
        # return JsonResponse({'error': 'Unable to fetch data'}, status=response.status_code)
        apiFail(message="Error fetching popular movies")

def sendToFrontEnd(message):
    """
    Publishes a message to the apiBE2FE queue

    Args:
        message: Dictionary containing api related data

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    queue = "apiBE2FE"

    channel.basic_publish(exchange='', routing_key=queue, body=json.dumps(message), properties=pika.BasicProperties(
        delivery_mode=2,  # Make the message persistent
    ))

    print(f"Response sent to apiBE2FE queue:\n{message} \n ")
    connection.close()

def sendToDatabase(message):
    """
    Publishes a message to the apiBE2DB queue

    Args:
        message: Dictionary containing api related data

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    queue = "apiBE2DB"

    channel.basic_publish(exchange='', routing_key=queue, body=json.dumps(message), properties=pika.BasicProperties(
        delivery_mode=2,  # Make the message persistent
    ))

    print(f"Response sent to apiBE2DB queue:\n{message} \n ")
    connection.close()

def apiFail(message):
    """
    Sends a failure message if there was an issue with the API

    Args
        message: Error message to send

    Returns:
        Json Response
    """
    try:
        failMessage = {
            "sender": "backend",
            "receiver": "frontend",
            "purpose": "api",
            "results": message,
            "status": "Failed"
        }

        sendToFrontEnd(failMessage)
    except Exception as e:
        print(f"Error processing apiFail request: {str(e)}")

def api_frontend_consumer():
    """
    Main consumer for apiFE2BE, uses callback function to respond appropriately

    Args:
        None

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    queue = "apiFE2BE"

    channel.queue_declare(queue=queue, durable=True)

    def callback(ch, method, properties, body):
        try:
            message_data = json.loads(body.decode())
            print(f"Received Message from apiFE2BE:\n{message_data}\n")
            if message_data.get("action") == "get_popular_movies":
                get_popular_movies(None, page=message_data.get("page"))
        except Exception as e:
            print(f'Error processing message: {str(e)}')

    channel.basic_consume(queue=queue, on_message_callback=callback, auto_ack=True)

    print('Waiting for messages on apiFE2BE. To exit press CTRL+C')
    channel.start_consuming()

def api_database_consumer():
    """
    Main consumer for apiDB2BE, uses callback function to respond appropriately

    Args:
        None

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    queue = "apiDB2BE"

    channel.queue_declare(queue=queue, durable=True)

    def callback(ch, method, properties, body):
        try:
            message_data = json.loads(body.decode())
            print(f"Received Message from apiDB2BE:\n{message_data}\n")

        except Exception as e:
            print(f'Error processing message: {str(e)}')

    channel.basic_consume(queue=queue, on_message_callback=callback, auto_ack=True)

    print('Waiting for messages on apiDB2BE. To exit press CTRL+C')
    channel.start_consuming()

def start_rabbitmq_consumers():
    """
    Function to start the api consumer queues through threads

    Args:
        None

    Returns:
        None
    """
    try:
        frontend_thread = threading.Thread(target=api_frontend_consumer, daemon=True)
        database_thread = threading.Thread(target=api_database_consumer, daemon=True)

        frontend_thread.start()
        database_thread.start()
    except Exception as e:
        print(f"Error starting api threads: {str(e)}")

