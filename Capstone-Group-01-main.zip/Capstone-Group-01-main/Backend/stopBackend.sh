#!/bin/bash

pkill -f "manage.py runserver"

echo "Backend Django server has stopped"