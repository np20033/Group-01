<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Movie Carousel</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      background-color: black;
    }

    #movie-container {
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
      margin: 20px auto;
    }

    .movie-card {
      flex: 0 0 300px;
      margin-right: 20px;
      border: 1px solid #ddd;
      border-radius: 5px;
      overflow: hidden;
      background-color: #fff;
    }

    .movie-card img {
      width: 100%;
      height: auto;
    }

    .navigation-arrows {
      display: flex;
      justify-content: center;
      margin-top: 20px;
    }

    .navigation-arrow {
      cursor: pointer;
      font-size: 24px;
      margin: 0 10px;
      color: #fff;
    }
  </style>
</head>
<body>
  <div id="movie-container"></div>
  <div class="navigation-arrows">
    <span class="navigation-arrow" onclick="prevMovie()">&#8592;</span>
    <span class="navigation-arrow" onclick="nextMovie()">&#8594;</span>
    <span class="navigation-arrow" onclick="upMovie()">&#8593;</span>
  </div>

  <script>
    const moviesData = {
      "results": [
        
        {
          "title": "The Holdovers",
          "release_date": "2023-10-27",
          "overview": "A curmudgeonly instructor at a New England prep school is forced to remain on campus during Christmas break to babysit the handful of students with nowhere to go. Eventually, he forms an unlikely bond with one of them — a damaged, brainy troublemaker — and with the school’s head cook, who has just lost a son in Vietnam.",
          "poster_path": "/VHSzNBTwxV8vh7wylo7O9CLdac.jpg"
        },
        // Add more movies here...
        {
          "title": "Terminator Genisys",
          "release_date": "2015-06-23",
          "overview": "The year is 2029. John Connor, leader of the resistance continues the war against the machines. At the Los Angeles offensive, John's fears of the unknown future begin to emerge when TECOM spies reveal a new plot by SkyNet that will attack him from both fronts; past and future, and will ultimately change warfare forever.",
          "poster_path": "/oZRVDpNtmHk8M1VYy1aeOWUXgbC.jpg"
        },
        {
          "title": "Deadpool & Wolverine",
          "release_date": "2024-07-24",
          "overview": "Third entry in the \"Deadpool\" franchise. Plot TBA.",
          "poster_path": "/uxBHXaoOvAwy4NpPpP7nNx2rXYQ.jpg"
        },
        {
          "title": "Pirates of the Caribbean: Dead Man's Chest",
          "release_date": "2006-07-06",
          "overview": "Captain Jack Sparrow works his way out of a blood debt with the ghostly Davy Jones to avoid eternal damnation.",
          "poster_path": "/uXEqmloGyP7UXAiphJUu2v2pcuE.jpg"
        },
        {
          "title": "Fifty Shades of Grey",
          "release_date": "2015-02-11",
          "overview": "When college senior Anastasia Steele steps in for her sick roommate to interview prominent businessman Christian Grey for their campus paper, little does she realize the path her life will take. Christian, as enigmatic as he is rich and powerful, finds himself strangely drawn to Ana, and she to him. Though sexually inexperienced, Ana plunges headlong into an affair -- and learns that Christian's true sexual proclivities push the boundaries of pain and pleasure.",
          "poster_path": "/63kGofUkt1Mx0SIL4XI4Z5AoSgt.jpg"
        },
        {
          "title": "Saltburn",
          "release_date": "2023-11-16",
          "overview": "Struggling to find his place at Oxford University, student Oliver Quick finds himself drawn into the world of the charming and aristocratic Felix Catton, who invites him to Saltburn, his eccentric family's sprawling estate, for a summer never to be forgotten.",
          "poster_path": "/qjhahNLSZ705B5JP92YMEYPocPz.jpg"
        },
        {
          "title": "Pirates of the Caribbean: At World's End",
          "release_date": "2007-05-19",
          "overview": "Captain Barbossa, long believed to be dead, has come back to life and is headed to the edge of the Earth with Will Turner and Elizabeth Swann. But nothing is quite as it seems.",
          "poster_path": "/jGWpG4YhpQwVmjyHEGkxEkeRf0S.jpg"
        },
        {
          "title": "Fantastic Beasts: The Secrets of Dumbledore",
          "release_date": "2022-04-06",
          "overview": "Professor Albus Dumbledore knows the powerful, dark wizard Gellert Grindelwald is moving to seize control of the wizarding world. Unable to stop him alone, he entrusts magizoologist Newt Scamander to lead an intrepid team of wizards and witches. They soon encounter an array of old and new beasts as they clash with Grindelwald's growing legion of followers.",
          "poster_path": "/jrgifaYeUtTnaH7NF5Drkgjg2MB.jpg"
        },
        {
          "title": "Taken 2",
          "release_date": "2012-09-27",
          "overview": "In Istanbul, retired CIA operative Bryan Mills and his wife are taken hostage by the father of a kidnapper Mills killed while rescuing his daughter.",
          "poster_path": "/yzAlcuJhpnxRPjaj7AHBRbNPQCJ.jpg"
        },
        {
          "title": "The Tomorrow War",
          "release_date": "2021-09-03",
          "overview": "The world is stunned when a group of time travelers arrive from the year 2051 to deliver an urgent message: Thirty years in the future, mankind is losing a global war against a deadly alien species. The only hope for survival is for soldiers and civilians from the present to be transported to the future and join the fight. Among those recruited is high school teacher and family man Dan Forester. Determined to save the world for his young daughter, Dan teams up with a brilliant scientist and his estranged father in a desperate quest to rewrite the fate of the planet.",
          "poster_path": "/34nDCQZwaEvsy4CFO5hkGRFDCVU.jpg"
        },
        {
          "title": "Sonic the Hedgehog",
          "release_date": "2020-02-12",
          "overview": "Powered with incredible speed, Sonic The Hedgehog embraces his new home on Earth. That is, until Sonic sparks the attention of super-uncool evil genius Dr. Robotnik. Now it’s super-villain vs. super-sonic in an all-out race across the globe to stop Robotnik from using Sonic’s unique power for world domination.",
          "poster_path": "/aQvJ5WPzZgYVDrxLX4R6cLJCEaQ.jpg"
        },
        {
          "title": "Concrete Utopia",
          "release_date": "2023-08-09",
          "overview": "The world has been reduced to rubble by a massive earthquake. While no one knows for sure how far the ruins stretch, or what the cause of the earthquake may be, in the heart of Seoul there is only one apartment building left standing. It is called Hwang Gung Apartments. As time passes, outsiders start coming in to Hwang Gung Apartments trying to escape the extreme cold. Before long, the apartment residents are unable to cope with the increasing numbers. Feeling a threat to their very survival, the residents enact a special measure.",
          "poster_path": "/4l68KHxnPSow8MvnGUpjqLzJtLJ.jpg"
        },
        {
          "title": "One More Shot",
          "release_date": "2024-01-12",
          "overview": "Following the attack on the black site in Poland, Navy SEAL Jake Harris is ordered to escort terrorist suspect Amin Mansur to Washington D.C. for interrogation. Before the prisoner transfer process is complete, though, the airport is attacked by a group of heavily armed, well-trained mercenaries.",
          "poster_path": "/4XxnWZzhMC1rOzUCJpc6CzmBIQe.jpg"
        },
        {
          "title": "The Conjuring: The Devil Made Me Do It",
          "release_date": "2021-05-25",
          "overview": "Paranormal investigators Ed and Lorraine Warren encounter what would become one of the most sensational cases from their files. The fight for the soul of a young boy takes them beyond anything they'd ever seen before, to mark the first time in U.S. history that a murder suspect would claim demonic possession as a defense.",
          "poster_path": "/xbSuFiJbbBWCkyCCKIMfuDCA4yV.jpg"
        },
        {
          "title": "Ponyo",
          "release_date": "2008-07-19",
          "overview": "When Sosuke, a young boy who lives on a clifftop overlooking the sea, rescues a stranded goldfish named Ponyo, he discovers more than he bargained for. Ponyo is a curious, energetic young creature who yearns to be human, but even as she causes chaos around the house, her father, a powerful sorcerer, schemes to return Ponyo to the sea.",
          "poster_path": "/yp8vEZflGynlEylxEesbYasc06i.jpg"
        },
        {
          "title": "Hotel Transylvania: Transformania",
          "release_date": "2022-01-31",
          "overview": "When Van Helsing's mysterious invention, the \"Monsterfication Ray,\" goes haywire, Drac and his monster pals are all transformed into humans, and Johnny becomes a monster. In their new mismatched bodies, Drac and Johnny must team up and race across the globe to find a cure before it's too late, and before they drive each other crazy.",
          "poster_path": "/teCy1egGQa0y8ULJvlrDHQKnxBL.jpg"
        },
        {
          "title": "Hacksaw Ridge",
          "release_date": "2016-10-07",
          "overview": "WWII American Army Medic Desmond T. Doss, who served during the Battle of Okinawa, refuses to kill people and becomes the first Conscientious Objector in American history to receive the Congressional Medal of Honor.",
          "poster_path": "/wuz8TjCIWR2EVVMuEfBnQ1vuGS3.jpg"
        },
        {
          "title": "Infiltration",
          "release_date": "2022-06-02",
          "overview": "Ivan sets off on a dangerous mission into Syria to save his ex-commander Grey after his capture by ISIS. With the help of U.S. military patrols, he succeeds in freeing Grey and attempts to escape the country while being hunted by terrorists.",
          "poster_path": "/nUI80er0ouSDgupOHaaZAntjUOK.jpg"
        },
        {
          "title": "Mission: Impossible - Fallout",
          "release_date": "2018-07-13",
          "overview": "When an IMF mission ends badly, the world is faced with dire consequences. As Ethan Hunt takes it upon himself to fulfill his original briefing, the CIA begin to question his loyalty and his motives. The IMF team find themselves in a race against time, hunted by assassins while trying to prevent a global catastrophe.",
          "poster_path": "/AkJQpZp9WoNdj7pLYSj1L0RcMMN.jpg"
        },
        {
          "title": "Justice League",
          "release_date": "2017-11-15",
          "overview": "Fuelled by his restored faith in humanity and inspired by Superman's selfless act, Bruce Wayne and Diana Prince assemble a team of metahumans consisting of Barry Allen, Arthur Curry and Victor Stone to face the catastrophic threat of Steppenwolf and the Parademons who are on the hunt for three Mother Boxes on Earth.",
          "poster_path": "/eifGNCSDuxJeS1loAXil5bIGgvC.jpg"
        }
      ]
    };

    const movieContainer = document.getElementById('movie-container');
    const navigationArrows = document.querySelectorAll('.navigation-arrow');

    let currentMovieIndex = 0;

    function displayMovie(index) {
      movieContainer.innerHTML = '';
      
      const movie = moviesData.results[index];
      const movieCard = document.createElement('div');
      movieCard.classList.add('movie-card');

      const title = document.createElement('h2');
      title.classList.add('movie-title');
      title.textContent = movie.title;

      const releaseDate = document.createElement('p');
      releaseDate.classList.add('movie-release-date');
      releaseDate.textContent = `Release Date: ${movie.release_date}`;

      const overview = document.createElement('p');
      overview.classList.add('movie-overview');
      overview.textContent = movie.overview;

      const poster = document.createElement('img');
      poster.classList.add('movie-poster');
      poster.src = `https://image.tmdb.org/t/p/w500/${movie.poster_path}`;
      poster.alt = `${movie.title} Poster`;

      movieCard.appendChild(title);
      movieCard.appendChild(releaseDate);
      movieCard.appendChild(overview);
      movieCard.appendChild(poster);

      movieContainer.appendChild(movieCard);
    }

    function nextMovie() {
      currentMovieIndex = (currentMovieIndex + 1) % moviesData.results.length;
      displayMovie(currentMovieIndex);
    }

    function prevMovie() {
      currentMovieIndex = (currentMovieIndex - 1 + moviesData.results.length) % moviesData.results.length;
      displayMovie(currentMovieIndex);
    }

    function upMovie() {
      window.scrollTo({top: 0, behavior: 'smooth'});
    }

    displayMovie(currentMovieIndex);
  </script>
</body>
</html>