#!/bin/bash

# Define the port number for the PHP server
PORT=7007

# Check if the port is already in use
if ps aux | grep -q "[p]hp -S localhost:$PORT"; then
    echo "Frontend server is already active at: http://localhost:$PORT"
else

# Start PHP server on localhost and the specified port
    php -S localhost:$PORT -t ./ >/dev/null 2>&1 &
    echo "Frontend server is now active at: http://localhost:$PORT"
fi




