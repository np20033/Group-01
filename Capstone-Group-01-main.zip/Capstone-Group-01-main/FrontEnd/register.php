<?php
session_start();
// Checks if the user is logged in. If they are, redirect them to the home page as register.php should not be accessible to logged-in users.
if (isset($_SESSION['username']) && isset($_SESSION['user_id'])) {
  header("Location: index.php");
  exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
  <link href="styles.css" rel="stylesheet" type="text/css" />
</head>
<body>
<nav class="navbar navbar-expand-md bg-dark-subtle justify-content-start">
  <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav ms-auto">
              <a class="nav-link" href="register.php">Register</a>
              <a class="nav-link" href="login.php">Login</a>
          </div>
          <div style="padding:5px"></div>
      </div>
  </div>
</nav>
<?php if(isset($_SESSION['success_message'])): ?>
      <div class="alert alert-success" role="alert">
          <?php echo $_SESSION['success_message']; ?>
      </div>
      <?php unset($_SESSION['success_message']); ?>
  <?php endif; ?>




<!-- Display error message if set -->
<div class="container-fluid col-lg-4 offset-lg-4">
  <h1 style="padding-top:10px;">Register</h1>
  <form method="post">
      <div class="mb-3">
          <label class="form-label" for="email">Email</label>
          <input class="form-control" type="email" id="email" name="email" required />
      </div>
      <div class="mb-3">
          <label class="form-label" for="username">Username</label>
          <input class="form-control" type="text" name="username" required maxlength="30" />
      </div>
      <div class="mb-3">
          <label class="form-label" for="firstname">First Name</label>
          <input  class="form-control" type="text" name="firstname" required maxlength="30" />
      </div>
      <div class="mb-3">
          <label class="form-label" for="lastname">Last Name</label>
          <input  class="form-control" type="text" name="lastname" required maxlength="30" />
      </div>
      <div class="mb-3">
          <label class="form-label" for="pw">Password</label>
          <input class="form-control" type="password" id="pw" name="password" required minlength="8" />
      </div>
      <div class="mb-3">
          <label class="form-label" for="confirm">Confirm Password</label>
          <input class="form-control" type="password" name="confirm" required minlength="8" />
      </div>
      <!-- Security Questions -->
      <div class="mb-3">
      <label class="form-label" for="security_question">Security Question:</label>
      <select class="form-select" id="security_question" name="security_question" required>
      <option value="">Select a Security Question</option>
      <option value="favorite_movie">What is your favorite movie?</option>
      <option value="hometown">What is your hometown?</option>
      <option value="pet_name">What is your pet's name?</option>
      </select>
      </div>
      <div class="mb-3">
      <label class="form-label" for="security_answer">Security Answer:</label>
      <input class="form-control" type="text" id="security_answer" name="security_answer" required />
      </div>
      <!-- End of Security Questions -->
      <input type="submit" class="mt-3 btn btn-primary" value="Register" />
  </form>


<?php


// Include the autoload file
require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection settings
$host = '172.23.182.238';
$port = 5672;
$user = 'admin';
$pass = 'admin';
$sendingQueue = 'regFE2BE'; // Sending
$receiveQueue = 'regBE2FE'; // Receiving
//$virtualhost = '/';
$exchangeName = 'reg_info';

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $email = $_POST['email'];
    $username = $_POST['username'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];
    $security_question = $_POST['security_question'];
    $security_answer = $_POST['security_answer'];

    $connection = null; // Initialize $connection outside the try-catch block

    try {
        // Attempt to create a connection
        $connection = new AMQPStreamConnection($host, $port, $user, $pass);
        $channel = $connection->channel();
        // Your code for RabbitMQ connection
    } catch (Exception $e) {
        // Handle connection errors
        die("Could not connect to RabbitMQ: " . $e->getMessage());
    }

  //$channel = $connection->channel();

    // Declare the exchange
    $channel->exchange_declare($exchangeName, 'direct', false, true, false);

    // Declare the queues
    $channel->queue_declare($sendingQueue, false, true, false, false);

    // Bind the queues to the exchange (no routing key needed)
    $channel->queue_bind($sendingQueue, $exchangeName);
    

    // Construct message payload
    $data = json_encode([
        "sender" => "frontend",
        "receiver" => "backend",
        "purpose" => "registration",
        "action" => "register_user_step1",
        "email" => $email,
        "username" => $username,
        "firstname" => $firstname,
        "lastname" => $lastname,
        "password" => $password,
        "confirm" => $confirm,
        "security_question" => $security_question,
        "security_answer" => $security_answer
    ]);


    // Define the message to send
    $message = new AMQPMessage($data);


    // Create a new AMQP message
    $message = new AMQPMessage($data, [
        'delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT,
        'reply_to' => $receiveQueue
    ]);


    // Publish the message to the queue
    $channel->basic_publish($message, $exchangeName);

 
    // Close the channel and the connection
    $channel->close();
    $connection->close();


    //Receive Message
    // Create a connection to RabbitMQ
    $receiveChannel = null;
    $receiveConnection = null;

    try {
        $receiveConnection = new AMQPStreamConnection($host, $port, $user, $pass);
        $receiveChannel = $receiveConnection->channel();
        echo "Connected to RabbitMQ successfully!\n";
    } catch (Exception $e) {
        die("Could not connect to RabbitMQ: " . $e->getMessage());
    }
    //$receiveChannel = $receiveConnection->channel();


    //Declare the queue
    $receiveChannel->queue_declare($receiveQueue, false, true, false, false);

    // Bind the queues to the exchange (no routing key needed)
    //$receiveChannel->queue_bind($receiveQueue, $exchangeName);


    // Define the callback function to process messages from the queue
    $receiveCallback = function ($receiveMessage) use ($receiveChannel) {
        $receiveData = json_decode($receiveMessage->body, true);

        // Log the received message for debugging
        echo "Received message: " . print_r($receiveData, true) . "\n";

        //Extract relevant information
        $status = $receiveData['status'];
        $results = $receiveData['results'];

        if ($status == "Success"){
            //Display success message to user
            echo "<script>alert('Registration successful!');</script>";
            echo "<script>location.href='login.php';</script>";
        } else if ($status == "Failed") {
            //Display the failed message to user
            echo "<script>alert('Registration failed: $results');</script>";
            echo "<script>location.href='register.php';</script>";
        }    

    };
    //consuming
    $receiveChannel->basic_consume($receiveQueue, '', false, true, false, false, $receiveCallback);

    // Keep consuming messages until the channel is closed
    while ($receiveChannel->is_consuming()) {
        $receiveChannel->wait();
        break;
    }
    
    // Close the connection
    $receiveChannel->close();
    $receiveConnection->close();

}

?>
</div>
<script src="script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>