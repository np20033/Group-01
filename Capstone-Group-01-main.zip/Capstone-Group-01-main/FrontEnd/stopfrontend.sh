#!/bin/bash

# Define the port number for the PHP server
PORT=7007
echo "Frontend is inactive."
pkill -f php




