#!/bin/bash

if sudo systemctl is-active --quiet rabbitmq-server; then
    echo "RabbitMQ is already running."
else
    # Start RabbitMQ
    sudo systemctl start rabbitmq-server
    echo "RabbitMQ started successfully."

fi