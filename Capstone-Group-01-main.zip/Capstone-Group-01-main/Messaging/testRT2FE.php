<?php

require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$username = 'admin';
$password = 'admin';

// Create a connection to RabbitMQ
$connection = new AMQPStreamConnection('172.23.182.238', 5672, 'admin', 'admin');
$channel = $connection->channel();


// Define the exchange and queue names
$exchangeName = 'movie_info';
$requestQueue = 'BE2RT';
$respondQueue = 'RT2FE';

// Declare the exchange and queues
$channel->queue_declare($requestQueue, false, true, false, false);
$channel->queue_declare($respondQueue, false, true, false, false);


// Callback function to handle received messages
$callback = function ($message) use ($channel, $respondQueue) {
    // Process the received message
    echo "Received request: " . print_r($message->body, true) . "\n";

    // Prepare the response message
    // $responseBody = json_encode([
    //     'function_name' => 'get_popular_movies',
    //     'page_number' => 3,
    // ]);

    // Publish the response message back to the frontend
   // $responseMessage = new AMQPMessage($responseBody);
    $responseMessage = $message;
    $channel->basic_publish($responseMessage, '', $respondQueue);

    echo "Response sent: $respondQueue\n";

    // Acknowledge the received message
    $message->delivery_info['channel']->basic_ack($message->delivery_info['delivery_tag']);
};

// Consume messages from the frontend
$channel->basic_consume($requestQueue, '', false, false, false, false, $callback);

// Listen for messages
while ($channel->is_consuming()) {
    $channel->wait();
}

// Close the connection
$channel->close();
$connection->close();

?>

