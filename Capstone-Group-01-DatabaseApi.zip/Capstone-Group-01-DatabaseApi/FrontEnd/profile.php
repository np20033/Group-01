<?php
session_start(); // Start the session
if (!isset($_SESSION["username"]) && !isset($_SESSION["user_id"])) {
  die(header("Location: login.php")); 
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1 id="username">Welcome!</h1>
    
    <!-- Display profile picture -->
    <div class="profile-picture">
        <img id="profile-pic" src="path/to/default_profile_picture.jpg" alt="Profile Picture">
        <button onclick="editProfilePicture()">Edit Picture</button>
    </div>
    
    <!-- Display folders -->
    <ul class="folders">
        <li><a href="#" onclick="filterMovies('folder1')">Folder 1</a></li>
        <li><a href="#" onclick="filterMovies('folder2')">Folder 2</a></li>
        <li><a href="#" onclick="filterMovies('folder3')">Folder 3</a></li>
    </ul>
    
    <!-- Movie list -->
    <div id="movie-list">
        <!-- Movies will be dynamically loaded here -->
    </div>

    <!-- Include any necessary JavaScript files -->
    <script src="script.js"></script>
</body>
</html>
