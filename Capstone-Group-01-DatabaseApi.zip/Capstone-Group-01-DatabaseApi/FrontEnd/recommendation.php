<?php
session_start(); // Start the session
if (!isset($_SESSION["username"]) && !isset($_SESSION["user_id"])) {
  die(header("Location: login.php")); 
}

?>