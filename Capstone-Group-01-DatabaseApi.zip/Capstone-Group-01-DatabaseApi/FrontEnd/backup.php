<?php

// Start the session before any output is sent
session_start();

require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection settings
$host = '172.23.182.238';
$port = 5672;
$user = 'admin';
$pass = 'admin';
$sendingQueue = 'apFE2RT'; //Sending
$receiveQueue = 'apRT2FE'; //Receive
$exchangeName = 'api_info'; 

$connection = null; //Initialize connection outside the try-catch block

try {
    // Attempt to create a connection
    $connection = new AMQPStreamConnection($host, $port, $user, $pass);
    //$channel = $connection->channel();
    // Your code for RabbitMQ connection
} catch (Exception $e) {
    // Handle connection errors
    die("Could not connect to RabbitMQ: " . $e->getMessage());
}

$channel = $connection->channel();

// Declare the exchange
$channel->exchange_declare($exchangeName, 'direct', false, true, false);

// Declare the queues
$channel->queue_declare($sendingQueue, false, true, false, false);
//$channel->queue_declare($responseQueue, false, true, false, false);

// Bind the queues to the exchange (no routing key needed)
$channel->queue_bind($sendingQueue, $exchangeName);
//$channel->queue_bind($responseQueue, $exchangeName);

// Initialize the page number
$pageNumber = 7;

// Construct message payload
$messageData = json_encode([
    "sender" => "frontend",
    "receiver" => "backend",
    "purpose" => "api",
    "action" => "get_popular_movies",
    "page" => $pageNumber
]);

// Define the message to send
$message = new AMQPMessage($messageData);

// Create a new AMQP message
$message = new AMQPMessage($messageData, [
    'delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT,
    'reply_to' => $receiveQueue
]);

// Publish the message to the queue
$channel->basic_publish($message, $exchangeName);

echo " [x] Sent 'get_popular_movies' request with page number: $pageNumber\n";

// Close the channel and the connection
$channel->close();
$connection->close();

//Receive Message
$receiveChannel = null;
$receiveConnection = null;

try{
    $receiveConnection = new AMQPStreamConnection($host,$port, $user, $pass);
    $receiveChannel = $receiveConnection->channel();
    echo "Connected to RabbitMQ Successfully!\n";
} catch (Exception $e) {
    die("Could not connect to RabbitMQ: " . $e->getMessage());
}
//$responseChannel = $responseConnection->channel();

echo "Declaring the response queue \n";
//Declare the queue
$receiveChannel->queue_declare($receiveQueue, false, true, false, false);

echo "Declared \n";

//Define the callback function to process the message
$receiveCallback = function ($receiveMessage) use ($receiveChannel) {
    $receiveData = json_decode($receiveMessage->body, true);
    
    //Log the received message for debugging
    echo "Received message: " . print_r($receiveData, true) . "\n";
    
};

// Consume messages from the response queue
$receiveChannel->basic_consume($receiveQueue, '', false, true, false, false, $receiveCallback);

// Keep consuming messages until the script is terminated
while ($receiveChannel->is_consuming()) {
    $receiveChannel->wait();
    break;
}

// Close the channel
$receiveChannel->close();
$receiveConnection->close();