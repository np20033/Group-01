<?php
session_start();

// Check if movie data is available in the session
if (!isset($_SESSION['movie_data']) || empty($_SESSION['movie_data'])) {
    // Redirect to getrequest.php to fetch the first batch of movies
    header("Location: getrequest.php");
    exit;
}

// Get movie data from session
$movieData = json_decode($_SESSION['movie_data'], true);

// Get current movie index from session
$currentMovieIndex = isset($_SESSION['current_movie_index']) ? $_SESSION['current_movie_index'] : 0;

// Extract results from the movie data
$results = isset($movieData['results']) ? $movieData['results'] : [];

// Check if there are results and the current movie index is within bounds
if (empty($results) || !isset($results[$currentMovieIndex])) {
    // Redirect to getrequest.php to fetch the next page of movies
    header("Location: getrequest.php");
    exit;
}

// Get the current movie data
$currentMovie = $results[$currentMovieIndex];

// Construct full poster URL
$basePosterUrl = "https://image.tmdb.org/t/p/w500";
$fullPosterUrl = isset($currentMovie["poster_path"]) ? $basePosterUrl . $currentMovie["poster_path"] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Homepage</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
<link href="styles.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="top-arrow">&#8593;</div>
<div class="container">
    <button class="arrow left-arrow">&#8592;</button>
    <div class="movie-card">
        <img class="movie-poster" src="<?php echo $fullPosterUrl; ?>" alt="Movie Poster">
        <div class="movie-details">
            <h2 class="title"><?php echo isset($currentMovie["title"]) ? $currentMovie["title"] : ''; ?></h2>
            <p><strong>Release Date:</strong> <span class="release-date"><?php echo isset($currentMovie["release_date"]) ? $currentMovie["release_date"] : ''; ?></span></p>
            <p><strong>Overview:</strong> <span class="overview"><?php echo isset($currentMovie["overview"]) ? $currentMovie["overview"] : ''; ?></span></p>
            <p><strong>Popularity:</strong> <span class="popularity"><?php echo isset($currentMovie["popularity"]) ? $currentMovie["popularity"] : ''; ?></span></p>
            <p><strong>Rating:</strong> <span class="rating"><?php echo isset($currentMovie["vote_average"]) ? $currentMovie["vote_average"] : ''; ?></span></p>
        </div>
    </div>
    <button class="arrow right-arrow">&#8594;</button>
</div>

<!-- Include JavaScript code here -->
<script>
document.querySelector('.left-arrow').addEventListener('click', function() {
    // Code to move the movie to the "not interested" folder
    alert('Movie moved to "Not Interested" folder.');
});

document.querySelector('.top-arrow').addEventListener('click', function() {
    // Code to move the movie to the "interested" folder
    alert('Movie moved to "Interested" folder.');
});

document.querySelector('.right-arrow').addEventListener('click', function() {
    // Code to move the movie to the "watched" folder
    alert('Movie moved to "Watched" folder.');
});
</script>
</body>
</html>