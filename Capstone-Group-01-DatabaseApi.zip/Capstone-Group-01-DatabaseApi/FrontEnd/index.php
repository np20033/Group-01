<?php
//session_start(); // Start the session
//if (!isset($_SESSION["username"]) && !isset($_SESSION["user_id"])) {
  //die(header("Location: login.php")); // Redirect to login page if user is not logged in
//}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
  <link href="styles.css" rel="stylesheet" type="text/css" />
</head>
<nav class="navbar navbar-expand-md bg-dark-subtle justify-content-start">
  <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav ms-auto">
            <a class="nav-link" href="home.php">Home</a>
            <a class="nav-link" href="logout.php">Logout</a>
          </div>
          <div style="padding:5px"></div>
      </div>
  </div>
</nav>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to MovieStacks</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('https://repository-images.githubusercontent.com/275336521/20d38e00-6634-11eb-9d1f-6a5232d0f84f');
            background-size: cover; /* Ensure the background image covers the entire viewport */
            background-position: center; /* Center the background image */
            color: #fff;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            text-align: center;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.7); /* Added a semi-transparent black background for better readability */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            font-size: 36px; /* Reduced font size */
            color: #fff;
            margin-bottom: 20px;
            text-transform: uppercase;
        }
        p {
            font-size: 18px;
            color: #b0b0b0;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .box {
            background-color: rgba(229, 9, 20, 0.7); /* Changed to a semi-transparent red color */
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
            text-align: left;
        }
        .box h2 {
            font-size: 24px;
            color: #fff;
            margin-bottom: 10px;
            text-align: center;
            text-transform: uppercase;
        }
        .box ul {
            list-style-type: disc;
            padding-left: 20px;
            color: #fff;
        }
        .box a {
            color: #fff;
            text-decoration: none;
            transition: color 0.3s;
        }
        .box a:hover {
            color: #b0b0b0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to MovieStacks</h1>
        <p>MovieStacks is a discovery social platform that allows users to find new movies, write reviews, and discuss with other movie enthusiasts. This platform enables users to discover new movies, keep track of the movies they have watched, and write reviews about the movies they have watched, facilitating discussions with other users.</p>
        <div class="box">
            <h2>Features</h2>
            <ul>
                <li>Review Feed: Public profiles feature user reviews on this feed. Users can read reviews and find movies of interest.</li>
                <li>Recommendation Page: Movies rated three stars or above display similar ones. Users select rated movies for recommendations.</li>
                <li>Communities Page: Users join genre-based communities, post content, and engage. They can like posts and join multiple communities.</li>
                <li>Discovery Page: Users swipe cards to show interest, watched, or disinterest, sorting movies into lists.</li>
                <li>Profile Page: Users toggle privacy, view movies, follow others, write reviews, manage requests, and view stats and achievements.</li>
            </ul>
        </div>
        <div class="box">
            <h2>Guidelines</h2>
            <ul>
                <li>Respect Copyrights: Only stream or download content you have rights to on Movie Stacks.</li>
                <li>Restrictions: Adhere to age limits for mature content.</li>
                <li>Report Issues: Promptly report technical problems or violations to support.</li>
                <li>Privacy Awareness: Safeguard personal info and adjust privacy settings accordingly on Movie Stacks.</li>
            </ul>
        </div>
    </div>
</body>
</html>