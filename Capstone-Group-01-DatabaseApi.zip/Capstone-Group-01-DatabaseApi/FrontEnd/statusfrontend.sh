#!/bin/bash

#Port
PORT=7007

#Status
if ps aux | grep -q "[p]hp -S localhost:$PORT"; then
    echo "Frontend server is active."
else
    echo "Frontend server is not active."
fi