#!/bin/bash

ssh drana7@172.23.182.238 'cd ~/Capstone-Group-01/Messaging && composer stopRabbitmq'
ssh drl3_it490server@172.23.199.180 'cd ~/Capstone-Group-01/Backend && composer stopBackend'
ssh khushi@172.23.94.225 'cd ~/Capstone-Group-01/FrontEnd && composer stopfrontend'
ssh mtg24@172.23.130.128 'cd ~/Capstone-Group-01/Database && composer stop-mysql'
ssh neha@172.23.119.210 'cd ~/Capstone-Group-01/Database && composer stop-mysql'

echo "All Services Stopped!"