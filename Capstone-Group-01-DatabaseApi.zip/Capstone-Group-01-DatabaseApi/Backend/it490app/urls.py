from django.urls import path
from .views import get_popular_movies

urlpatterns = [
    path('popular_movies/<int:page>/', get_popular_movies, name='popular_movies'),
]