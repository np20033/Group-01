#!/bin/bash

if pgrep -f "python3.10 manage.py runserver" > /dev/null; then
    echo "Backend Django server is already running"
else
    echo "Backend Django server starting up..."
    nohup python3.10 manage.py runserver 8080 > backend.log 2>&1 &
fi