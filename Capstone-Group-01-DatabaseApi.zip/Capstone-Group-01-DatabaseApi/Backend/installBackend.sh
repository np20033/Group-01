#!/bin/bash

sudo apt update
sudo app install python3
sudo apt update
sudo apt install python3-django