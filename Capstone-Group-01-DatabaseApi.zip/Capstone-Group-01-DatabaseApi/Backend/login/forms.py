from django import forms

class UserLoginValidationForm(forms.Form):
    username_email = forms.CharField(max_length=50)
    password = forms.CharField(max_length=50)