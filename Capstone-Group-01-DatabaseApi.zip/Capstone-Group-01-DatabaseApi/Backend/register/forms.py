from django import forms

class UserRegisterValidationForm(forms.Form):
    firstname = forms.CharField(max_length=50)
    lastname = forms.CharField(max_length=50)
    username = forms.CharField(max_length=50)
    password = forms.CharField(max_length=50)
    confirm = forms.CharField(max_length=50)
    email = forms.EmailField()
    security_question = forms.CharField(max_length=100)
    security_answer = forms.CharField(max_length=50)