from django.shortcuts import render
import json
import pika
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from .forms import UserRegisterValidationForm
from django.contrib.auth.hashers import make_password
import threading
import time
import re

def checkValidForm(data):
    """
    Checks if the inputted data is a valid first name, last name, username, email, and password

    Args:
        data: Dictionary containing user registration data

    Returns:
        None
    """
    form = UserRegisterValidationForm(data)
    if form.is_valid():
        password = form.cleaned_data['password']
        confirm_password = form.cleaned_data['confirm']
        if len(password) < 8:
            registrationFail(None, message="Password must have at least 8 characters")
        elif not re.search(r'[^A-Za-z0-9]', password):
            registrationFail(None, message="Password must have at least one special character")
        elif not re.search(r'[0-9]', password):
            registrationFail(None, message="Password must have at least one digit")
        elif not re.search(r'[A-Z]', password):
            registrationFail(None, message="Password must have at least one uppercase letter")
        elif not re.search(r'[a-z]', password):
            registrationFail(None, message="Password must have at least one lowercase letter")
        elif password == confirm_password:
            userExists(data)
        else:
            registrationFail(None, message="Passwords do not match")
    else:
        registrationFail(None, message="Invalid Username/Email/Password")

def userExists(data):
    """
    Checks if the user exists through username and email (sends request to database)

    Args:
        data: Dictionary containing user registration data

    Returns:
        None
    """
    form = UserRegisterValidationForm(data)
    if form.is_valid():
        f_name = form.cleaned_data['firstname']
        l_name = form.cleaned_data['lastname']
        username = form.cleaned_data['username']
        hashed_password = make_password(form.cleaned_data['password'])
        email = form.cleaned_data['email']
        security_question = form.cleaned_data['security_question']
        security_answer = form.cleaned_data['security_answer']

        user_exists = {
            "sender": "backend",
            "receiver": "database",
            "purpose": "registration",
            "action": "register_user_step2",
            "email": email,
            "username": username,
            "firstname": f_name,
            "lastname": l_name,
            "password": hashed_password,
            "security_question": security_question,
            "security_answer": security_answer
        }

        sendToDatabase(user_exists)
    else:
        registrationFail(None, message="Invalid Username/Email/Password")

def createUser(data):
    """
    Creates the user account (sends request to database)

    Args:
        data: Dictionary containing user registration data

    Returns:
        None
    """
    f_name = data.get("firstname")
    l_name = data.get("lastname")
    username = data.get("username")
    email = data.get("email")
    password = data.get("password")
    security_question = data.get("security_question")
    security_answer = data.get("security_answer")

    create_user = {
        "sender": "backend",
        "receiver": "database",
        "purpose": "registration",
        "action": "register_user_step4",
        "email": email,
        "username": username,
        "firstname": f_name,
        "lastname": l_name,
        "password": password,
        "security_question": security_question,
        "security_answer": security_answer
    }

    # print(create_user)
    sendToDatabase(create_user)

def registrationSuccess(data):
    """
    Sends a success message once the user account is created (sends to frontend)

    Args:
        data: Dictionary containing user registration data

    Returns:
        None
    """
    successMessage = {
        "sender": "backend",
        "receiver": "frontend",
        "purpose": "registration",
        "results": data.get("results"),
        "status": "Success"
    }

    sendToFrontEnd(successMessage)

def registrationFail(data, message):
    """
    Sends a failure message (sends to frontend)

    Args:
        data: Dictionary containing user registration data
        message: Error message

    Returns:
        None
    """
    failMessage = {
        "sender": "backend",
        "receiver": "frontend",
        "purpose": "registration",
        "results": message,
        "status": "Failed"
    }

    sendToFrontEnd(failMessage)

def sendToFrontEnd(message):
    """
    Publishes a message to the regBE2FE queue

    Args:
        message: Dictionary containing user registration data

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    # Creating the connection to RabbitMQ Server
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    # Declaring the queue
    queue ='regBE2FE'

    channel.basic_publish(exchange='', routing_key=queue, body=json.dumps(message), properties=pika.BasicProperties(
        delivery_mode=2,  # Make the message persistent
    ))
    print(f"Response sent to regBE2FE queue:\n{message} \n ")
    connection.close()

def sendToDatabase(message):
    """
    Publishes a message to the regBE2DB queue

    Args:
        message: Dictionary containing user registration data

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    # Creating the connection to RabbitMQ Server
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    # Declaring the queue
    queue = 'regBE2DB'

    channel.basic_publish(exchange='', routing_key=queue, body=json.dumps(message), properties=pika.BasicProperties(
        delivery_mode=2,  # Make the message persistent
    ))
    print(f"Response sent to regBE2DB queue:\n{message} \n ")
    connection.close()


def register_frontend_consumer():
    """
    Main consumer for regFE2BE, uses callback function to respond appropriately

    Args:
        None

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    # Creating the connection to RabbitMQ Server
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    # Declaring the QUEUE NAME
    queue = "regFE2BE"
    channel.queue_declare(queue=queue, durable=True)

    def callback(ch, method, properties, body):
        try:
            message_data = json.loads(body.decode())
            print(f"Received Message from regFE2BE: \n{message_data}\n")

            if message_data.get("action") == "register_user_step1":
                checkValidForm(message_data)
            elif "error" in message_data:
                registrationFail(None, message=message_data.get("error"))
        except Exception as e:
            registrationFail(None, message=str(e))

    # Waiting for Messages to Consume
    channel.basic_consume(queue=queue, on_message_callback=callback, auto_ack=True)

    print('Waiting for messages on regFE2BE. To exit press CTRL+C')
    channel.start_consuming()

def register_database_consumer():
    """
    Main consumer for regDB2BE, uses callback function to respond appropriately

    Args:
        None

    Returns:
        None
    """
    host = '172.23.182.238'
    port = 5672
    credentials = pika.PlainCredentials('admin', 'admin')
    virtual_host = '/'

    # Creating the connection to RabbitMQ Server
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials))
    channel = connection.channel()

    # Declaring the QUEUE NAME
    queue = "regDB2BE"
    channel.queue_declare(queue=queue, durable=True)

    def callback(ch, method, properties, body):
        try:
            message_data = json.loads(body.decode())
            print(f"Received Message from regRT2DB: \n{message_data}\n")

            if message_data.get("action") == "register_user_step3":
                userExistsCheck = message_data.get("results")
                if not userExistsCheck:
                    createUser(message_data)
                else:
                    registrationFail(None, message="Username/Email taken")
            elif message_data.get("action")  == "register_user_step5":
                createdAccount = message_data.get("results")
                if createdAccount:
                    registrationSuccess(message_data)
                else:
                    registrationFail(None, message=message_data.get("results"))
            elif "error" in message_data:
                registrationFail(None, message=message_data.get("error"))
        except Exception as e:
            registrationFail(None, message=str(e))

    # Waiting for Messages to Consume
    channel.basic_consume(queue=queue, on_message_callback=callback, auto_ack=True)

    print('Waiting for messages on regDB2BE. To exit press CTRL+C')
    channel.start_consuming()

def start_rabbitmq_consumers():
    """
    Function to start the registration consumer queues through threads

    Args:
        None

    Returns:
        None
    """
    try:
        frontend_thread = threading.Thread(target=register_frontend_consumer, daemon=True)
        database_thread = threading.Thread(target=register_database_consumer, daemon=True)

        frontend_thread.start()
        database_thread.start()
    except Exception as e:
        print(f"Error starting register threads: {str(e)}")


