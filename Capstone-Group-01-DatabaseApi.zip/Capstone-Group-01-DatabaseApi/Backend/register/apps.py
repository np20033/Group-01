from django.apps import AppConfig
from .views import start_rabbitmq_consumers

class RegisterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'register'

    def ready(self):
        # Start the RabbitMQ consumer when the app is ready
        start_rabbitmq_consumers()