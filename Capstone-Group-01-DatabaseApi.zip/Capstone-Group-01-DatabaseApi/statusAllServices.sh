#!/bin/bash

ssh drana7@172.23.182.238 'cd ~/Capstone-Group-01/Messaging && systemctl status rabbitmq-server'
ssh drl3_it490server@172.23.199.180 'cd ~/Capstone-Group-01/Backend && composer statusBackend'
ssh khushi@172.23.94.225 'cd ~/Capstone-Group-01/FrontEnd && composer statusfrontend'
ssh mtg24@172.23.130.128 'cd ~/Capstone-Group-01/Database && composer status-mysql'
ssh neha@172.23.119.210 'cd ~/Capstone-Group-01/Database && composer status-mysql'

echo "Status of all services completed"