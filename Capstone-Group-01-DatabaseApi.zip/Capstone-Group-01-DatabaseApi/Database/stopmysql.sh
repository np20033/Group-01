#/bin/bash
sudo systemctl stop mysql.service 
echo "MYSQL stops running"
#sudo systemctl status mysql.service


