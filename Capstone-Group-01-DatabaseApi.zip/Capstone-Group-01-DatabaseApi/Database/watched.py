import mysql.connector
import json
import pika

# MySQL database connection details
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'password'
MYSQL_DATABASE = 'moviestacks'

# RabbitMQ connection details
RABBITMQ_HOST = '172.23.182.238'

# Function to connect to the MySQL database
def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE
        )
        print("Connected to MySQL database")
        return connection
    except mysql.connector.Error as e:
        print("Error connecting to MySQL database:", e)
        return None

# Function to connect to RabbitMQ
def connect_to_rabbitmq():
    try:
        credentials = pika.PlainCredentials("admin", "admin")
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, port=5672, virtual_host='/', credentials=credentials))
        channel = connection.channel()
        print("Connected to RabbitMQ on host:", RABBITMQ_HOST)
        return channel
    except Exception as e:
        print("Error connecting to RabbitMQ:", e)
        return None

# Function to send message to RabbitMQ
def send_message_to_rabbitmq(channel, message):
    try:
        channel.queue_declare(queue='apiDB2BE', durable=True)
        channel.basic_publish(exchange='', routing_key='apiDB2BE', body=json.dumps(message))
        print(f" [x] Sent message to queue {'apiDB2BE'}: {message}")
    except Exception as e:
        print("Error sending message to RabbitMQ:", e)

# Function to check if a movie exists in the database
def check_movie_existence(cursor, tmdb_id):
    cursor.execute("SELECT * FROM movies WHERE movie_id = %s", (tmdb_id,))
    return cursor.fetchone() is not None

# Function to add a movie to the database
def add_movie(cursor, movie_data):
    try:
        cursor.execute("INSERT INTO movies (movie_id, title, overview, poster_path, vote_average, vote_count) VALUES (%s, %s, %s, %s, %s, %s)",
                       (movie_data['id'], movie_data['title'], movie_data['overview'], movie_data['poster_path'], movie_data['vote_average'], movie_data['vote_count']))
        print("Added movie to the database:", movie_data['title'])
        results = True
    except Exception as e:
        print("Error adding movie to the database:", e)
        results = False

    # Send message to backend
    message = {
        "sender": "database",
        "receiver": "backend",
        "purpose": "api",
        "action": "add_watched",
        "results": results
    }
    send_message_to_rabbitmq(connect_to_rabbitmq(), message)

# Function to connect a movie to a user
def connect_movie_to_user(cursor, user_id, tmdb_id):
    try:
        cursor.execute("INSERT INTO user_watched_movies(user_id, movie_id) VALUES (%s, %s)", (user_id, tmdb_id))
        print("Connected movie to the user")
        results = True
    except Exception as e:
        print("Error connecting movie to the user:", e)
        results = False

    # Send message to backend
    message = {
        "sender": "database",
        "receiver": "backend",
        "purpose": "api",
        "action": "add_watched",
        "results": results
    }
    send_message_to_rabbitmq(connect_to_rabbitmq(), message)

# Function to receive messages from RabbitMQ
def receive_message_from_rabbitmq(channel):
    def callback(ch, method, properties, body):
        message = json.loads(body)
        if message['action'] == 'add_watched':
            movie_data = message['data']
            user_id = message['username']
            tmdb_id = movie_data['id']

            db_connection = connect_to_database()
            if db_connection:
                cursor = db_connection.cursor()
                
                if not check_movie_existence(cursor, tmdb_id):
                    add_movie(cursor, movie_data)
                
                connect_movie_to_user(cursor, user_id, tmdb_id)
                
                db_connection.commit()
                db_connection.close()

    try:
        channel.queue_declare(queue='apiBE2DB', durable=True)
        channel.basic_consume(queue='apiBE2DB', on_message_callback=callback, auto_ack=True)
        print(" [*] Waiting for messages. To exit, press CTRL+C")
        channel.start_consuming()
    except Exception as e:
        print("Error receiving message from RabbitMQ:", e)


if __name__ == "__main__":
    rabbitmq_channel = connect_to_rabbitmq()
    if rabbitmq_channel:
        receive_message_from_rabbitmq(rabbitmq_channel)
