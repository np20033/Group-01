#!/bin/bash

sudo systemctl stop rabbitmq-server
echo "rabbitmq stop running"

