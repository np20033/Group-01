<?php

require_once __DIR__ . '/vendor/autoload.php'; // Include the library

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection
$connection = new AMQPStreamConnection('172.23.182.238', 5672, 'admin', 'admin');
$channel = $connection->channel();

// Define the exchange and queue names
$exchangeName = 'api_info';
$requestQueue = 'apFE2RT';
$respondQueue = 'apRT2BE';

// Declare the queues
$channel->queue_declare($requestQueue, false, true, false, false);
$channel->queue_declare($respondQueue, false, true, false, false);
echo " [*] Waiting for messages. To exit press CTRL+C\n";


// Callback function to handle received message
$callback = function($message) use ($channel, $respondQueue) {

    echo "[x] Recived request:" .print_r($message->body, true) . "\n";

    $responseMessage = $message;
    $channel->basic_publish($responseMessage,'',$respondQueue);
    echo " [x] Sent '$responseMessage->body' to $respondQueue\n";

    $message->delivery_info['channel']->basic_ack($message->delivery_info['delivery_tag']);
 };

// Consume messages from the frontend
$channel->basic_consume($requestQueue, '', false, false, false, false, $callback);

// Listen for messages
while ($channel->is_consuming()) {
    $channel->wait();
}

// Close the connection
$channel->close();
$connection->close();

?>