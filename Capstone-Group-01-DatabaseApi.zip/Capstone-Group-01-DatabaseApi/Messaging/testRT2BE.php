<?php

//M2 deliverables

require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$username = 'admin';
$password = 'admin';

// Create a connection to RabbitMQ
$connection = new AMQPStreamConnection('172.23.182.238', 5672, 'admin', 'admin');
$channel = $connection->channel();

// Define the queue name
$queueName = 'RT2BE';

// Declare the queue
$channel->queue_declare($queueName, false, true, false, false);


// Publish the message
$messageBody = json_encode([
    'action' => 'get_popular_movies',
    'page_number' => 4,
]);

$message = new AMQPMessage($messageBody);
$channel->basic_publish($message, '', $queueName);

echo "Message sent: $messageBody\n";


// Close the connection
$channel->close();
$connection->close();

// This script working

?>

