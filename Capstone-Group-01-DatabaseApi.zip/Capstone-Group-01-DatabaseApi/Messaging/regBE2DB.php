<?php

require_once __DIR__ . '/vendor/autoload.php'; // Include the library

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

//RabbitMQ connection
$connection = new AMQPStreamConnection('172.23.182.238', 5672, 'admin', 'admin');
$channel = $connection->channel();

// Define the exchange and queue names
//$exchangeName = 'movie_info';
$requestQueue = 'regBE2RT';
$respondQueue = 'regRT2DB';

// Declare the exchange and queues
$channel->queue_declare($requestQueue, false, true, false, false);
 $channel->queue_declare($respondQueue, false, true, false, false);
echo " [*] Waiting for messages. To exit press CTRL+C\n";

//Callback function
$callback = function ($msg) use ($channel) {
    $message = json_decode($msg->body, true);
    echo $msg->body;
    if ($message['receiver'] == 'database') {
        $channel->queue_declare('regRT2DB', false, true, false, false);
        $channel->basic_publish(new AMQPMessage($msg->body), '', 'regRT2DB');
       // echo " [x] Sent '$responseMessage->body' to $respondQueue\n";

       echo "Message sent to Database Queue (regRT2DB) \n";

    } else if ($message['receiver'] == 'frontend') {
        $channel->queue_declare('regRT2FE', false, true, false, false);
        $channel->basic_publish(new AMQPMessage($msg->body), '', 'regRT2FE');
        echo "Message sent to Frontend Queue (regRT2FE) \n";
    }
};

// Consume messages from the queues
$channel->basic_consume($requestQueue, '', false, false, false, false, $callback);
    // echo 'Received message:';

while ($channel->is_consuming()) {
    $channel->wait();
}

$channel->close();
$connection->close();

?>