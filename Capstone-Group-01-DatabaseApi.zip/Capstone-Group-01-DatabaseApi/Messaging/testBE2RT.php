<?php

//M2 deliverables

require_once __DIR__. '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// Create a connection to RabbitMQ
$connection = new AMQPStreamConnection('172.23.182.238', 5672, 'admin', 'admin');
$channel = $connection->channel();

// Define the queue name
$queueName = 'BE2RT';

// Declare the queue as durable
$channel->queue_declare($queueName, false, true, false, false);

echo " [*] Waiting for messages. To exit press CTRL+C\n";

$callback = function ($msg) {
    echo ' [x] Received ', $msg->getBody(), "\n";
};

//Consume the message
$channel->basic_consume('BE2RT', '', false, true, false, false, $callback);

try {
    $channel->consume();
} catch (\Throwable $exception) {
    echo $exception->getMessage();
}

// Close the connection
$channel->close();
$connection->close();

?>
